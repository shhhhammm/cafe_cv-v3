# test project > 2024-03-30 8:43pm
https://universe.roboflow.com/test-96owp/test-project-fudxz

Provided by a Roboflow user
License: CC BY 4.0

